# VitalGrid Analytics — Desktop Launcher Setup

Two launcher files are included:

- **`launch_vitalgrid.vbs`** — silent launcher (no terminal window). This is the one you'll turn into your desktop icon.
- **`launch_vitalgrid_debug.bat`** — visible terminal version. Use this only if the silent one doesn't work, so you can see error messages.

## Step 1 — Edit the paths

Open `launch_vitalgrid.vbs` in Notepad and change this line to your actual project folder:

```vbs
projectPath = "C:\Users\YourName\Projects\vitalgrid"
```

Right-click your project folder in File Explorer → **Copy as path**, then paste it in (remove the quotes it copies, the script already has its own).

Do the same for `launch_vitalgrid_debug.bat` if you plan to keep it as a backup.

## Step 2 — Test it

Double-click `launch_vitalgrid.vbs`.
- Nothing visible should happen for a few seconds.
- Then your default browser should open to `http://localhost:8501` with your dashboard.

**If it doesn't work:**
1. Run `launch_vitalgrid_debug.bat` instead — it'll show the actual error in a terminal window.
2. Common issues:
   - `'streamlit' is not recognized` → Streamlit isn't on your PATH. If you installed it in a virtual environment, edit the `streamlitCmd` line in the `.vbs` file to point to `venv\Scripts\streamlit.exe` inside your project folder.
   - Wrong port → if your app doesn't load at `localhost:8501`, check the debug terminal for the actual port Streamlit printed and update the URL at the bottom of the `.vbs` file.
   - File not found → double check `scriptName` matches your file exactly, including the parentheses.

## Step 3 — Get an icon file (.ico)

Windows shortcuts need a `.ico` file specifically (not `.png` or `.jpg`).

- If you already have a logo image, upload it in the chat and it can be converted to `.ico`.
- If not, describe what you want (e.g. "a heartbeat/pulse icon in blue and white") and one can be generated for you.

## Step 4 — Create the desktop shortcut

1. Right-click `launch_vitalgrid.vbs` → **Send to** → **Desktop (create shortcut)**
2. Go to your Desktop, right-click the new shortcut → **Properties**
3. Click **Change Icon...** → **Browse...** → select your `.ico` file → **OK** → **Apply**
4. Rename the shortcut to **VitalGrid Analytics**

Now double-clicking the desktop icon will silently start Streamlit and open your dashboard in the browser — no terminal required.

## Optional — Stop the server

Streamlit keeps running in the background after the browser opens (that's normal — closing the browser tab doesn't stop the server). To fully stop it:

- Open Task Manager → find the `python.exe` or `streamlit.exe` process → **End Task**
- Or, if you want, a `stop_vitalgrid.bat` script can be added that kills the process automatically — just ask.
