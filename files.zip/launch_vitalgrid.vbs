' ============================================================
'  VitalGrid Analytics - Silent Launcher
'  Double-click this file to start the Streamlit app with
'  no terminal window, then auto-open it in your browser.
' ============================================================

Set WshShell = CreateObject("WScript.Shell")

' --- EDIT THIS: full path to the FOLDER containing app(2).py ---
projectPath = "C:\Users\YourName\Projects\vitalgrid"

' --- EDIT THIS if your script has a different name ---
scriptName = "app(2).py"

' --- EDIT THIS if you use a virtual environment ---
' Leave as "streamlit" if streamlit is installed globally / on PATH.
' If you use a venv, point this to the full path of streamlit.exe inside it, e.g.:
' streamlitCmd = projectPath & "\venv\Scripts\streamlit.exe"
streamlitCmd = "streamlit"

WshShell.CurrentDirectory = projectPath

' Run Streamlit completely hidden (0 = hidden window, False = don't wait for it to finish)
WshShell.Run "cmd /c """ & streamlitCmd & " run " & """" & scriptName & """" & " --server.headless true""", 0, False

' Give the server a few seconds to boot before opening the browser
WScript.Sleep 5000

' Open the dashboard (default Streamlit port is 8501)
WshShell.Run "http://localhost:8501"
