@echo off
REM ============================================================
REM  VitalGrid Analytics - Debug Launcher (shows terminal output)
REM  Use this version if the silent .vbs launcher doesn't work,
REM  so you can see any error messages.
REM ============================================================

REM --- EDIT THIS: full path to the FOLDER containing app(2).py ---
cd /d "C:\Users\YourName\Projects\vitalgrid"

echo Starting VitalGrid Analytics...
echo (Close this window to stop the app)
echo.

streamlit run "app(2).py"

pause
